package P2;

public class HinhTron implements IHinhHoc {
    double r;
	public HinhTron(double r) {
		super();
		this.r = r;
	}
    public double dt() {
    	return r*r*3.14;
    }
    public double cv() {
    	return 2*r*3.14;
    }
}
