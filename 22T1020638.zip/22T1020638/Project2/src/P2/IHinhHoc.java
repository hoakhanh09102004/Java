package P2;

public interface IHinhHoc {
    public abstract double cv();
    public abstract double dt();
}
