package P2;

public class HinhChuNhat implements IHinhHoc {
	double r;
	double d;
	
    public HinhChuNhat(double r, double d) {
		super();
		this.r = r;
		this.d = d;
	}
	public double dt() {
    	return r*d;
    }
    public double cv() {
    	return 2*(r+d);
    }
}
