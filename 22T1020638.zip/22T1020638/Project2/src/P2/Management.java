package P2;

public class Management {

	public static void main(String[] args) {
		IHinhHoc x = new HinhTron(4);
		System.out.println("Dien tich hinh tron la: "+x.dt());
		System.out.println("Chu vi hinh tron la: "+x.cv());
		IHinhHoc y = new HinhChuNhat(5,6);
		System.out.println("Dien tich hinh chu nhat la: "+y.dt());
		System.out.println("Chu vi hinh chu nhat la: "+y.cv());
	}

}
