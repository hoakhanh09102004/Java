package P1;

public abstract class HinhHoc {
    public abstract double cv();
    public abstract double dt();
}
