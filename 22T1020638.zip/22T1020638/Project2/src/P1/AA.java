package P1;

public abstract class AA {
   private String ten;
   private double dtb;
   public AA(String ten, double dtb) {
	 super();
	 this.ten = ten;
	 this.dtb = dtb;
   }
   public void f1() {
   	 System.out.println("AA");
   }
   public abstract void f2();
}
