package P1;

public class HinhChuNhat extends HinhHoc{
     private double d;
     private double r;
	 public HinhChuNhat(double d, double r) {
		super();
		this.d = d;
		this.r = r;
	}
	 public double cv() {
	    return (d+r)*2;
	}
	 public double dt() {
	    return d*r;
	 }
}
