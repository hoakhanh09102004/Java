package P1;

public class Management {

	public static void main(String[] args) {
		HinhHoc x= new HinhTron(4); //upcasting
		//x.cv();
		//x.dt();
		System.out.println("Chu vi hinh tron la:"+x.cv());
		System.out.println("Dien tich hinh tron la:"+x.dt());
		HinhHoc y = new HinhChuNhat(3,5); //upcasting
        //y.cv();
        //y.dt();
        System.out.println("Chu vi hinh chu nhat la:"+y.cv());
        System.out.println("Dien tich hinh chu nhat la:"+y.dt());
	}

}
