package P1;

public class HinhTron extends HinhHoc{
    private double r;

	public HinhTron(double r) {
		super();
		this.r = r;
	}
    public double cv() {
    	return 2*3.14*r;
    }
    public double dt() {
    	return r*3.14*r;
    }
}
