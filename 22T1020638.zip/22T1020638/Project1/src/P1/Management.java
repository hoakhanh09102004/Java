package P1;

public class Management {

	public static void main(String[] args) {
		AA x = new AA();
		x.f1();
		AA y = new BB();
		y.f1();
		}
}
