package P1;

public class BB extends AA {
	public void f1() {
    	System.out.println("BB");
    }
}
