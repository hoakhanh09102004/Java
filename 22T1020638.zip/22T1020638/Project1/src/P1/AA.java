package P1;

public class AA {
    public void f1() {
    	System.out.println("AA");
    }
}
