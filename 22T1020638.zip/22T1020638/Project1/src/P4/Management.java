package P4;

import java.util.regex.Pattern;

public class Management {

	public static void main(String[] args) {
		String bt = "[0-9]{3}[-][a-zA-Z]{4}[-][0-9]{2}[a-zA-Z]{2}";
		String seri = "345-Abcd-78XY";//truong hop dung
		//String seri = "123-1Hhh-Dc78";//truong hop sai
		System.out.println(Pattern.matches(bt,seri));
	}

}
