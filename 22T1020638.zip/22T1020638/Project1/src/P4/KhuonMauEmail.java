package P4;

import java.util.regex.Pattern;

public class KhuonMauEmail {

	public static void main(String[] args) {
		String bt1 = "[\\w]{1,}[@][\\D]{1,}[.][\\D]{1,}";
		String bt2 = bt1+"[.][\\D]{1,}";
		//String email = "22T1020638@husc.edu.vn";
		//String email = "22T1020638@gmail.com";
		String email = "22T1020638@gmail";
		System.out.println(Pattern.matches(bt1,email)||Pattern.matches(bt2,email));
	}

}
