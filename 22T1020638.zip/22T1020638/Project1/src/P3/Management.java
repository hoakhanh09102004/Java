package P3;

import java.util.regex.Pattern;

public class Management {

	public static void main(String[] args) {
		String bt = "[0][0-9]{9,10}";// số 0 đầu tiên là bắt buộc và 9->10 số ngẫu nhiên từ 0-9
		String sodt = "0123456789";
		System.out.println(Pattern.matches(bt,sodt));//khuôn mẫu/dạng
	}

}
