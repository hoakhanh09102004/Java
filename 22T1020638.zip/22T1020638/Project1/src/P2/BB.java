package P2;

public class BB {
     public void f2() {
    	 System.out.println("BB");
     }
}
