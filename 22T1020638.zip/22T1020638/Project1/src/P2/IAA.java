package P2;

public interface IAA {
     public abstract void f1();
}
