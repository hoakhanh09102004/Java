package P2;

public class CC extends BB implements IAA{//nhieu interface sau IAA,...,...
     public void f1(){
    	System.out.println("AA"); 
     }
}
