package P2;

public class Management {

	public static void main(String[] args) {
		CC x = new CC();// Thấy được x.f1 x.f2
		x.f2();x.f1();
		BB y = new CC();// Thấy được y.f2
		y.f2();
		IAA z= new CC();// Thấy được z.f1
		z.f1();
	}
}
