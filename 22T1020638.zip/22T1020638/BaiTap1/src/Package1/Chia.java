package Package1;

public class Chia extends Tinh {
	public double a;
    public double b;
    public Chia(double a, double b) {
		super();
		this.a = a;
		this.b = b;
	}
    public double kq(){
    	return a/b;
    }
}
