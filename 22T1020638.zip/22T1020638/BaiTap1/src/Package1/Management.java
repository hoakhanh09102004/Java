package Package1;

public class Management {

	public static void main(String[] args) {
		Tinh x = new Cong(2,3);
		System.out.println("Ket qua phep cong la:"+x.kq());
		Tinh y = new Tru(4,3);
		System.out.println("Ket qua phep tru la:"+y.kq());
		Tinh z = new Nhan(2,3);
		System.out.println("Ket qua phep nhan la:"+z.kq());
		Tinh c = new Chia(9,3);
		System.out.println("Ket qua phep chia la:"+c.kq());
	}

}
