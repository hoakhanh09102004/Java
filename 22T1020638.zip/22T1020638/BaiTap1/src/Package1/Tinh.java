package Package1;

public abstract class Tinh {
    public abstract double kq();
}
